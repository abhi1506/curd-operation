package com.blackoffer.crudoperation.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.blackoffer.crudoperation.entity.User;

public interface UserRepo extends JpaRepository<User, Long> {

}
