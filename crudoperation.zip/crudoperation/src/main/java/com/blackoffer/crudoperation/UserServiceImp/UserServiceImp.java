package com.blackoffer.crudoperation.UserServiceImp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.blackoffer.crudoperation.UserService.UserService;
import com.blackoffer.crudoperation.entity.User;
import com.blackoffer.crudoperation.repository.UserRepo;

@Service
public class UserServiceImp implements UserService {

	@Autowired
	private UserRepo userRepo;

	@Override
	public User saveUser(User user) {
		return userRepo.save(user);
	}

	@Override
	public List<User> findAllUser() {
		return userRepo.findAll();
	}

	@Override
	public void removeById(Long id) {

		userRepo.deleteById(id);

	}

	@Override
	public User updateUser(User user, Long id) {
		if (userRepo.findById(id).isPresent()) {
			User existingUser = userRepo.findById(id).get();
			existingUser.setFirstName(user.getFirstName());
			existingUser.setContact(user.getContact());

			User updatedUser = userRepo.save(existingUser);
			return updatedUser;
		}
		return null;

	}

}
