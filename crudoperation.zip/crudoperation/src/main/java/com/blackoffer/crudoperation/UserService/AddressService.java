package com.blackoffer.crudoperation.UserService;

import com.blackoffer.crudoperation.entity.Address;

public interface AddressService {

	Address saveAddress(Address address);

}
