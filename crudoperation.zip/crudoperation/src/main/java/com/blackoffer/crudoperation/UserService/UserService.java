package com.blackoffer.crudoperation.UserService;

import java.util.List;

import com.blackoffer.crudoperation.entity.User;

public interface UserService {

	User saveUser(User user);

	List<User> findAllUser();

	void removeById(Long id);

	User updateUser(User user,Long id);

}
