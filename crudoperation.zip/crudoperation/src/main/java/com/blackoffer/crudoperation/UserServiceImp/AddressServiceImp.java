package com.blackoffer.crudoperation.UserServiceImp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.blackoffer.crudoperation.UserService.AddressService;
import com.blackoffer.crudoperation.entity.Address;
import com.blackoffer.crudoperation.repository.AddressRepo;

@Service
public class AddressServiceImp implements AddressService {

	@Autowired
	private AddressRepo addressRepo;

	@Override
	public Address saveAddress(Address address) {

		return addressRepo.save(address);
	}

}
